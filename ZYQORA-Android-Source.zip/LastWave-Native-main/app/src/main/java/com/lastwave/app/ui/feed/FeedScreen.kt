package com.lastwave.app.ui.feed

import androidx.activity.compose.BackHandler
import com.lastwave.app.playback.toPlayableTrack
import androidx.compose.material.icons.filled.Download
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.AllInclusive
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.NewReleases
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.runtime.DisposableEffect
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import kotlinx.coroutines.flow.SharedFlow
import com.lastwave.app.ui.navigation.FEED_TAP_DEBOUNCE_MS
import com.lastwave.app.ui.navigation.FeedTapAction
import com.lastwave.app.ui.navigation.resolveFeedTapAction
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.heading
import com.lastwave.app.R
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lastwave.app.ui.feed.cards.CardTokens
import com.lastwave.app.ui.feed.cards.CardTextArea
import com.lastwave.app.ui.feed.cards.rememberCoverHeight
import com.lastwave.app.ui.feed.cards.rememberSquareCardWidth
import com.lastwave.app.ui.feed.cards.rememberWideCardWidth
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.lastwave.app.data.feed.FeedAlbum
import com.lastwave.app.data.feed.FeedArtist
import com.lastwave.app.data.feed.FeedQuickTile
import com.lastwave.app.data.feed.FeedSpotlight
import com.lastwave.app.util.ArtistHelper
import com.lastwave.app.data.generate.GeneratedTrack
import com.lastwave.app.data.local.HomeSection
import com.lastwave.app.data.model.FriendEntry
import com.lastwave.app.data.model.RecentTrack
import com.lastwave.app.data.music.YouTubeMusicTrack
import com.lastwave.app.data.music.YouTubePlaylistSummary
import com.lastwave.app.data.music.HomeChip
import com.lastwave.app.data.music.HomeShelf
import com.lastwave.app.data.music.HomeShelfItem
import com.lastwave.app.playback.PlayableTrack
import com.lastwave.app.ui.common.ArtworkImage
import com.lastwave.app.ui.common.ExpressiveHeader
import com.lastwave.app.ui.common.HeaderActionIcon
import com.lastwave.app.ui.common.TrackContextMenuSheet
import com.lastwave.app.ui.common.TrackMiniTrayData
import com.lastwave.app.ui.common.TrackMiniTraySheet
import com.lastwave.app.ui.common.WindowSizeClass
import com.lastwave.app.ui.common.rememberWindowSizeClass
import com.lastwave.app.ui.common.TrackMenuCapabilities
import com.lastwave.app.ui.common.TrackMenuTarget
import com.lastwave.app.ui.common.ExpressiveInlineLoadingIndicator
import com.lastwave.app.ui.common.adaptiveContentWidth
import com.lastwave.app.ui.common.safeHorizontalContentPadding
import com.lastwave.app.ui.navigation.ArtistAlbumNavigator
import com.lastwave.app.ui.player.LocalMusicPlayer
import com.lastwave.app.ui.player.PlayingWaveBars
import com.lastwave.app.ui.shell.FloatingNavDefaults
import com.lastwave.app.ui.podcast.PodcastShowRow


@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun FeedScreen(
    onOpenSettings: () -> Unit,
    onOpenSearch: () -> Unit,
    onOpenDiscover: () -> Unit,
    onOpenFeedPlaylist: (String) -> Unit,
    onOpenPlaylist: (Long) -> Unit = {},
    onOpenGenerator: () -> Unit = {},
    onOpenFriends: () -> Unit = {},
    onOpenDownloads: () -> Unit = {},
    onOpenFriendProfile: (username: String, displayName: String?, avatarUrl: String?) -> Unit = { _, _, _ -> },
    onOpenNewReleases: () -> Unit = {},
    onOpenPodcasts: () -> Unit = {},
    onOpenPodcastShow: (String) -> Unit = {},
    feedTapEvents: SharedFlow<Unit>? = null,
    viewModel: FeedViewModel = hiltViewModel(),
    artistAlbumNavigator: ArtistAlbumNavigator = hiltViewModel<ArtistAlbumNavBridgeFeed>().navigator,
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    BackHandler(enabled = state.selectedChip != null) {
        viewModel.selectChip(null)
    }
    val discoveryTracks by viewModel.discoveryTracks.collectAsStateWithLifecycle()
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, viewModel) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_START) viewModel.onVisible()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val musicPlayer = LocalMusicPlayer.current
    val context = LocalContext.current
    val playbackState by musicPlayer.chromeState.collectAsStateWithLifecycle()
    var menuTrack by remember { mutableStateOf<YouTubeMusicTrack?>(null) }
    // Long-press (deep press) mini tray — 3-dot buttons keep the full sheet.
    var miniTrayTrack by remember { mutableStateOf<TrackMiniTrayData?>(null) }
    // Sections hidden via Settings → Home sections.
    val hiddenSections by viewModel.hiddenHomeSections.collectAsStateWithLifecycle()
    val podcastsEnabled by viewModel.podcastsEnabled.collectAsStateWithLifecycle()
    fun isSectionVisible(section: HomeSection) = section.id !in hiddenSections
    val snackbarHostState = remember { SnackbarHostState() }
    val hasFeedContent = state.isChipActive || with(state.feedData) {
        nativeShelves.any { it.items.isNotEmpty() } ||
            quickTiles.isNotEmpty() || mixes.isNotEmpty() || topArtists.isNotEmpty() ||
            quickPicks.isNotEmpty() || jumpBackIn.isNotEmpty() || recentAlbums.isNotEmpty() ||
            heavyRotation.isNotEmpty() || ytLikedSongs.isNotEmpty() || ytRecentSongs.isNotEmpty() ||
            (becauseYouListenTo?.items?.isNotEmpty() == true) || freshFinds.isNotEmpty() ||
            spotlight != null || charts.isNotEmpty() || newReleases.isNotEmpty() || friends.isNotEmpty() ||
            podcastShows.isNotEmpty()
    }
    val showSynthetic = !state.isChipActive
    val listState = rememberLazyListState()
    var lastFeedTapMillis by remember { mutableLongStateOf(0L) }
    var isFeedTapRefreshing by remember { mutableStateOf(false) }

    LaunchedEffect(state.isRefreshing) {
        if (!state.isRefreshing) {
            isFeedTapRefreshing = false
        }
    }

    LaunchedEffect(feedTapEvents) {
        feedTapEvents?.collect {
            val now = System.currentTimeMillis()
            val isAtTop = listState.firstVisibleItemIndex == 0 && listState.firstVisibleItemScrollOffset == 0
            val isChipSelected = state.selectedChip != null
            val isRefreshing = state.isRefreshing || isFeedTapRefreshing

            val action = resolveFeedTapAction(
                isChipSelected = isChipSelected,
                isAtTop = isAtTop,
                isOnHomeFeed = true,
                isRefreshing = isRefreshing,
                nowMs = now,
                lastTapMs = lastFeedTapMillis,
                debounceMs = FEED_TAP_DEBOUNCE_MS,
            )

            when (action) {
                FeedTapAction.DeselectChipAndRefresh -> {
                    lastFeedTapMillis = now
                    isFeedTapRefreshing = true
                    viewModel.selectChip(null)
                    listState.animateScrollToItem(0)
                    viewModel.refresh()
                }
                FeedTapAction.ScrollTopAndRefresh -> {
                    lastFeedTapMillis = now
                    isFeedTapRefreshing = true
                    listState.animateScrollToItem(0)
                    viewModel.refresh()
                }
                FeedTapAction.RefreshOnly -> {
                    lastFeedTapMillis = now
                    isFeedTapRefreshing = true
                    viewModel.refresh()
                }
                FeedTapAction.NavigateToFeed,
                FeedTapAction.Ignore -> { /* ignored */ }
            }
        }
    }
    val shouldLoadMore by remember(listState) {
        derivedStateOf {
            val total = listState.layoutInfo.totalItemsCount
            val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            total > 0 && last >= total - 3
        }
    }
    LaunchedEffect(shouldLoadMore, state.pagedShelves.size, state.chipShelves.size) {
        if (shouldLoadMore && !state.isLoading && !state.isLoadingMore && !state.isRefreshing && !state.isChipLoading) {
            viewModel.loadMoreHomeShelves()
        }
    }
    val greeting = remember {
        when (java.time.LocalTime.now().hour) {
            in 5..11 -> context.getString(R.string.feed_greeting_morning)
            in 12..16 -> context.getString(R.string.feed_greeting_afternoon)
            in 17..21 -> context.getString(R.string.feed_greeting_evening)
            else -> context.getString(R.string.feed_greeting_night)
        }
    }
    val formattedDate = remember {
        try {
            java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("EEEE, MMMM d"))
        } catch (_: Exception) { "" }
    }
    LaunchedEffect(state.error, hasFeedContent) {
        val error = state.error ?: return@LaunchedEffect
        if (hasFeedContent) {
            val result = snackbarHostState.showSnackbar(error, actionLabel = context.getString(R.string.feed_retry), withDismissAction = true)
            viewModel.dismissError()
            if (result == SnackbarResult.ActionPerformed) viewModel.refresh()
        }
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .adaptiveContentWidth(maxWidth = 920.dp),
        ) {
            ExpressiveHeader(
                title = stringResource(R.string.feed_home),
                actions = {
                    HeaderActionIcon(Icons.Filled.Download, "Downloads", onOpenDownloads)
                    HeaderActionIcon(Icons.Filled.Search, "Search", onOpenSearch)
                    IconButton(onClick = onOpenSettings) {
                        com.lastwave.app.ui.home.ProfileAvatar(avatarUrl = state.avatarUrl, modifier = Modifier.size(38.dp))
                    }
                },
            )

            // Pinned YTM chip row under the app bar — stays visible while the
            // feed scrolls beneath it. Rendered only when chips exist; its
            // loading/filtering/selection behaviour is unchanged.
            if (state.homeChips.isNotEmpty()) {
                PinnedChipsBar(
                    chips = state.homeChips,
                    selectedChip = state.selectedChip,
                    onChipClick = viewModel::onHomeChipSelected,
                )
            }

            PullToRefreshBox(
                isRefreshing = state.isRefreshing,
                onRefresh = viewModel::refresh,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
            ) {
                if (state.isLoading) {
                FeedLoadingSkeleton()
            } else if (!hasFeedContent) {
                FeedEmptyState(
                    message = if (state.error != null) {
                        "We couldn't load your recommendations. Try again, or find something in search."
                    } else {
                        "Search for a favorite or explore something new. Your music starts here."
                    },
                    onRetry = viewModel::loadFeed,
                    onOpenSearch = onOpenSearch,
                )
            } else {
                val individualTopArtists = remember(state.feedData.topArtists) {
                    state.feedData.topArtists.flatMap { artist ->
                        val split = ArtistHelper.splitArtists(artist.name)
                        if (split.size <= 1) {
                            listOf(artist.copy(name = ArtistHelper.primaryArtist(artist.name)))
                        } else {
                            split.map { singleName ->
                                FeedArtist(
                                    name = singleName,
                                    browseId = if (singleName.equals(artist.name, ignoreCase = true)) artist.browseId else null,
                                    artworkUrl = artist.artworkUrl,
                                )
                            }
                        }
                    }.distinctBy { it.name.trim().lowercase() }
                }

                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize().safeHorizontalContentPadding(),
                    contentPadding = PaddingValues(
                        bottom = FloatingNavDefaults.contentBottomPadding(),
                        top = 12.dp,
                    ),
                    verticalArrangement = Arrangement.spacedBy(CardTokens.sectionGap),
                ) {
                    if (showSynthetic && isSectionVisible(HomeSection.HERO)) {
                    item(key = "hero") {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 18.dp)
                                    .padding(top = 2.dp),
                                verticalArrangement = Arrangement.spacedBy(2.dp),
                            ) {
                                Text(
                                    text = greeting,
                                    style = MaterialTheme.typography.headlineMedium.copy(
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        letterSpacing = (-0.3).sp,
                                    ),
                                    color = MaterialTheme.colorScheme.onSurface,
                                )
                                if (formattedDate.isNotBlank()) {
                                    Text(
                                        text = formattedDate,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Medium,
                                        ),
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f),
                                    )
                                }
                            }
                            InfiniteRadioHero(
                                quickPicks = state.feedData.quickPicks,
                                onPlay = viewModel::playInfiniteRadio,
                            )
                        }
                    }
                    }

                    val quickTiles = if (state.feedData.isYtConnected) {
                        state.feedData.quickTiles.filter { it.collection != "live_map" }
                    } else {
                        state.feedData.quickTiles.filter {
                            it.collection != "live_map" &&
                                it.collection != "yt_liked" && it.collection != "yt_recent" &&
                                it.playlistId != "yt_liked" && it.playlistId != "yt_recent"
                        }
                    }
                    if (showSynthetic && isSectionVisible(HomeSection.QUICK_TILES) && quickTiles.isNotEmpty()) {
                        item(key = "quick_tiles") {
                            Surface(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                                shape = RoundedCornerShape(24.dp),
                                color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.5f),
                            ) {
                                Column(modifier = Modifier.padding(vertical = 12.dp)) {
                            FeedSectionHeader(title = stringResource(R.string.feed_quick_access))
                                    Spacer(modifier = Modifier.height(12.dp))
                            QuickTilesGrid(
                                tiles = quickTiles,
                                onTileClick = { tile ->
                                    when {
                                        tile.collection == "radio" -> onOpenDiscover()
                                        tile.collection == "discover_mix" -> viewModel.playDiscoverMix(tile)
                                        tile.collection == "mix" -> onOpenGenerator()
                                        tile.collection == "my_mix" -> {
                                            if (tile.playlistId != null) {
                                                viewModel.playPlaylistById(tile.playlistId, tile.title)
                                            } else {
                                                viewModel.playInfiniteRadio()
                                            }
                                        }
                                        tile.collection == "yt_liked" || tile.playlistId == "yt_liked" -> onOpenFeedPlaylist("yt_liked")
                                        tile.collection == "yt_recent" || tile.playlistId == "yt_recent" -> onOpenFeedPlaylist("yt_recent")
                                        tile.collection == "new_releases" -> onOpenNewReleases()
                                        tile.localPlaylistId != null -> onOpenPlaylist(tile.localPlaylistId)
                                        tile.playlistId != null -> onOpenFeedPlaylist(tile.playlistId)
                                        else -> viewModel.handleQuickTileClick(tile)
                                    }
                                },
                            )
                        
                                }
                            }
                        }
                    }

                    if (showSynthetic && podcastsEnabled && state.feedData.podcastShows.isNotEmpty()) {
                        item(key = "podcast_shelf") {
                            Column(Modifier.padding(vertical = 4.dp)) {
                                FeedSectionHeader(
                                    title = state.feedData.podcastShelfTitle
                                        ?.takeIf { it.isNotBlank() }
                                        ?: stringResource(R.string.podcasts_title),
                                    actionText = stringResource(R.string.podcasts_see_all),
                                    actionIcon = Icons.AutoMirrored.Filled.ArrowForwardIos,
                                    onActionClick = onOpenPodcasts,
                                )
                                Spacer(Modifier.height(8.dp))
                                PodcastShowRow(
                                    shows = state.feedData.podcastShows,
                                    onShowClick = { show -> onOpenPodcastShow(show.showId) },
                                )
                            }
                        }
                    }

                    // 3. "Your Sound" Section - ALWAYS visible below Quick Access
                    if (showSynthetic) {
                        val displayTags = state.feedData.tasteTags.ifEmpty {
                            listOf("Rock", "Indie", "Pop", "Electronic", "Hip-Hop", "R&B", "Synthwave", "Alternative")
                        }
                        item(key = "taste_strip") {
                            TasteStrip(
                                tags = displayTags,
                                launching = state.launchingRadio,
                                onTagClick = { tag -> viewModel.playDiscoveryQuery(tag.displayName(), tag) },
                            )
                        }
                    }

                    // YouTube Music mood/activity chips (Relax, Energize, Workout,
                    // ...) are pinned at the top under the app bar — see the
                    // PinnedChipsBar rendered above the LazyColumn. Loading,
                    // filtering and selection logic are unchanged; only the
                    // row's position moved from between feed sections to the top.

                    if (state.isChipActive) {
                        if (state.isChipLoading) {
                            // Card-shaped shimmer placeholders that mirror the
                            // native shelf layout the chip page will render.
                            item(key = "chip_loading_skeleton") {
                                Column(verticalArrangement = Arrangement.spacedBy(CardTokens.sectionGap)) {
                                    com.lastwave.app.ui.feed.cards.ShelfSquareSkeletonRow(
                                        cardWidth = com.lastwave.app.ui.feed.cards.rememberSquareCardWidth(),
                                    )
                                    com.lastwave.app.ui.feed.cards.ShelfWideSkeletonRow(
                                        cardWidth = com.lastwave.app.ui.feed.cards.rememberWideCardWidth(),
                                    )
                                }
                            }
                        } else {
                            for ((shelfIndex, shelf) in state.chipShelves.withIndex()) {
                                if (shelf.items.isEmpty()) continue
                                item(key = "chip_shelf_${shelfIndex}_${shelf.title}") {
                                    HomeShelfCard(
                                        shelf = shelf,
                                        onPlayTrack = { track, title -> viewModel.playTrack(track, title) },
                                        onPlayTracksQueue = { tracks, idx, title -> viewModel.playTracksQueue(tracks, idx, title) },
                                        onShuffleTracksQueue = { tracks, title -> viewModel.shuffleTracksQueue(tracks, title) },
                                        onOpenFeedPlaylist = onOpenFeedPlaylist,
                                        onOpenAlbum = { title, artist, id -> artistAlbumNavigator.openAlbum(title, artist, id) },
                                        onTrackLongClick = { tray -> miniTrayTrack = tray },
                                    )
                                }
                            }
                        }
                    } else {
                        // Native YouTube Music shelves (exact titles, original order, original items)
                        for ((shelfIndex, shelf) in state.feedData.nativeShelves.withIndex()) {
                            if (shelf.items.isEmpty()) continue
                            item(key = "native_shelf_${shelfIndex}_${shelf.title}") {
                                HomeShelfCard(
                                    shelf = shelf,
                                    onPlayTrack = { track, title -> viewModel.playTrack(track, title) },
                                    onPlayTracksQueue = { tracks, idx, title -> viewModel.playTracksQueue(tracks, idx, title) },
                                    onShuffleTracksQueue = { tracks, title -> viewModel.shuffleTracksQueue(tracks, title) },
                                    onOpenFeedPlaylist = onOpenFeedPlaylist,
                                    onOpenAlbum = { title, artist, id -> artistAlbumNavigator.openAlbum(title, artist, id) },
                                    onTrackLongClick = { tray -> miniTrayTrack = tray },
                                )
                            }
                        }
                    }

                    if (showSynthetic && isSectionVisible(HomeSection.QUICK_PICKS) && state.feedData.quickPicks.isNotEmpty()) {
                        item(key = "quick_picks") {
                            Surface(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                                shape = RoundedCornerShape(24.dp),
                                color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.5f),
                            ) {
                                Column(modifier = Modifier.padding(vertical = 12.dp)) {
                            val title = if (state.feedData.hasYtRecommendations) stringResource(R.string.feed_picked_you) else stringResource(R.string.feed_quick_picks)
                            val subtitle = if (state.feedData.hasYtRecommendations) {
                                stringResource(R.string.feed_from_listening)
                            } else if (state.feedData.hasPersonalContent) {
                                stringResource(R.string.feed_matched_taste)
                            } else {
                                stringResource(R.string.feed_trending_worth)
                            }
                            FeedSectionHeader(
                                title = title,
                                subtitle = subtitle,
                                actionText = stringResource(R.string.feed_play_all),
                                actionIcon = Icons.Filled.PlayArrow,
                                onActionClick = { viewModel.playTracksQueue(state.feedData.quickPicks, 0, "Quick Picks") },
                                onShuffleClick = { viewModel.shuffleTracksQueue(state.feedData.quickPicks, "Quick Picks") },
                            )
                            QuickPicksRows(
                                tracks = state.feedData.quickPicks,
                                currentPlayingVideoId = playbackState.current?.videoId,
                                isPlaying = playbackState.isPlaying,
                                onTrackClick = { index ->
                                    val track = state.feedData.quickPicks.getOrNull(index)
                                    if (track != null) {
                                        viewModel.playTrack(track, "Quick Picks")
                                    } else {
                                        viewModel.playTracksQueue(state.feedData.quickPicks, index, "Quick Picks")
                                    }
                                },
                                onMenuClick = { menuTrack = it },
                                onLongClick = { track, index ->
                                    miniTrayTrack = TrackMiniTrayData(
                                        title = track.title,
                                        artist = track.artist,
                                        album = track.album,
                                        artworkUrl = track.artworkUrl,
                                        videoId = track.videoId.takeIf(String::isNotBlank),
                                        sourceLabel = "Home",
                                        onPlay = { viewModel.playTrack(track, "Quick Picks") },
                                    )
                                },
                            )
                        
                                }
                            }
                        }
                    }

                    if (showSynthetic && discoveryTracks.isNotEmpty()) {
                        item(key = "discover_new_music") {
                            Surface(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                                shape = RoundedCornerShape(24.dp),
                                color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.5f),
                            ) {
                                Column(modifier = Modifier.padding(vertical = 12.dp)) {
                                    FeedSectionHeader(
                                        title = stringResource(R.string.feed_discover),
                                        subtitle = stringResource(R.string.feed_discover_sub),
                                        actionText = stringResource(R.string.feed_see_all),
                                        actionIcon = Icons.AutoMirrored.Filled.ArrowForwardIos,
                                        onActionClick = onOpenDiscover,
                                    )
                                    FeedMediaRow(
                                        content = {
                                            itemsIndexed(discoveryTracks) { index, track ->
                                                val playable = track.toPlayableTrack()
                                                FeedMediaCard(
                                                    title = track.name,
                                                    subtitle = ArtistHelper.primaryArtist(track.artist),
                                                    artworkUrl = track.artworkUrl,
                                                    fallbackIcon = Icons.Filled.Explore,
                                                    badgeText = "DISCOVER",
                                                    onClick = {
                                                        val queue = discoveryTracks.map { it.toPlayableTrack() }
                                                        musicPlayer.playDiscoverQueue(queue, index)
                                                    },
                                                    onPlayClick = {
                                                        val queue = discoveryTracks.map { it.toPlayableTrack() }
                                                        musicPlayer.playDiscoverQueue(queue, index)
                                                    },
                                                )
                                            }
                                        },
                                    )
                                }
                            }
                        }
                    }

                    if (showSynthetic && isSectionVisible(HomeSection.BECAUSE_YOU_LISTEN_TO)) {
                    state.feedData.becauseYouListenTo?.takeIf { it.items.isNotEmpty() }?.let { section ->
                        item(key = "because_you_listen_to") {
                            Surface(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                                shape = RoundedCornerShape(24.dp),
                                color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.5f),
                            ) {
                                Column(modifier = Modifier.padding(vertical = 12.dp)) {
                            FeedSectionHeader(
                                title = section.title,
                                subtitle = section.subtitle,
                                actionText = stringResource(R.string.feed_play_all),
                                actionIcon = Icons.Filled.PlayArrow,
                                onActionClick = { viewModel.playTracksQueue(section.items, 0, section.title) },
                                onShuffleClick = { viewModel.shuffleTracksQueue(section.items, section.title) },
                            )
                            FeedMediaRow(
                                content = {
                                    itemsIndexed(section.items) { index, track ->
                                        FeedMediaCard(
                                            title = track.title,
                                            subtitle = ArtistHelper.primaryArtist(track.artist),
                                            artworkUrl = track.artworkUrl,
                                            fallbackIcon = Icons.Filled.MusicNote,
                                            onClick = { viewModel.playTrack(track, section.title) },
                                            onLongClick = {
                                                miniTrayTrack = TrackMiniTrayData(
                                                    title = track.title,
                                                    artist = track.artist,
                                                    album = track.album,
                                                    artworkUrl = track.artworkUrl,
                                                    videoId = track.videoId.takeIf(String::isNotBlank),
                                                    sourceLabel = "Home",
                                                    onPlay = { viewModel.playTrack(track, section.title) },
                                                )
                                            },
                                            onPlayClick = { viewModel.playTrack(track, section.title) },
                                        )
                                    }
                                },
                            )
                        
                                }
                            }
                        }
                    }
                    }

                    if (showSynthetic && isSectionVisible(HomeSection.FRESH_FINDS) && state.feedData.freshFinds.isNotEmpty()) {
                        item(key = "fresh_finds") {
                            Surface(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                                shape = RoundedCornerShape(24.dp),
                                color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.5f),
                            ) {
                                Column(modifier = Modifier.padding(vertical = 12.dp)) {
                                    FeedSectionHeader(
                                        title = stringResource(R.string.feed_fresh),
                                        subtitle = stringResource(R.string.feed_fresh_sub),
                                        actionText = stringResource(R.string.feed_play_all),
                                        actionIcon = Icons.Filled.PlayArrow,
                                        onActionClick = { viewModel.playTracksQueue(state.feedData.freshFinds, 0, "Fresh Finds") },
                                        onShuffleClick = { viewModel.shuffleTracksQueue(state.feedData.freshFinds, "Fresh Finds") },
                                    )
                                    FeedMediaRow(
                                        content = {
                                            itemsIndexed(state.feedData.freshFinds) { index, track ->
                                                FeedMediaCard(
                                                    title = track.title,
                                                    subtitle = ArtistHelper.primaryArtist(track.artist),
                                                    artworkUrl = track.artworkUrl,
                                                    fallbackIcon = Icons.Filled.Whatshot,
                                                    badgeText = "NEW",
                                                    onLongClick = {
                                                        miniTrayTrack = TrackMiniTrayData(
                                                            title = track.title,
                                                            artist = track.artist,
                                                            album = track.album,
                                                            artworkUrl = track.artworkUrl,
                                                            videoId = track.videoId.takeIf(String::isNotBlank),
                                                            sourceLabel = "Home",
                                                            onPlay = { viewModel.playTrack(track, "Fresh Finds") },
                                                        )
                                                    },
                                                    onClick = { viewModel.playTrack(track, "Fresh Finds") },
                                                    onPlayClick = { viewModel.playTrack(track, "Fresh Finds") },
                                                )
                                            }
                                        },
                                    )
                                }
                            }
                        }
                    }

                    if (showSynthetic && isSectionVisible(HomeSection.JUMP_BACK_IN) && state.feedData.jumpBackIn.isNotEmpty()) {
                        item(key = "jump_back_in") {
                            Surface(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                                shape = RoundedCornerShape(24.dp),
                                color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.5f),
                            ) {
                                Column(modifier = Modifier.padding(vertical = 12.dp)) {
                            FeedSectionHeader(
                                title = stringResource(R.string.feed_jump),
                                subtitle = stringResource(R.string.feed_jump_sub),
                                actionText = stringResource(R.string.feed_play_all),
                                actionIcon = Icons.Filled.PlayArrow,
                                onActionClick = { viewModel.playRecentQueue(state.feedData.jumpBackIn, 0) },
                            )
                            FeedMediaRow(
                                content = {
                                    itemsIndexed(state.feedData.jumpBackIn) { index, track ->
                                        RecentTrackCard(
                                            track = track,
                                            onClick = { viewModel.playRecentQueue(state.feedData.jumpBackIn, index) },
                                            onLongClick = {
                                                miniTrayTrack = TrackMiniTrayData(
                                                    title = track.name,
                                                    artist = track.artist.displayName,
                                                    artworkUrl = track.artworkUrl,
                                                    sourceLabel = "Home",
                                                    onPlay = { viewModel.playRecentQueue(state.feedData.jumpBackIn, index) },
                                                )
                                            },
                                        )
                                    }
                                },
                            )
                        
                                }
                            }
                        }
                    }

                    if (showSynthetic && isSectionVisible(HomeSection.MIXES) && state.feedData.mixes.isNotEmpty()) {
                        item(key = "mixed_for_you") {
                            Surface(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                                shape = RoundedCornerShape(24.dp),
                                color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.5f),
                            ) {
                                Column(modifier = Modifier.padding(vertical = 12.dp)) {
                            FeedSectionHeader(
                                title = stringResource(R.string.feed_mixes),
                                subtitle = stringResource(R.string.feed_mixes_sub),
                                actionText = stringResource(R.string.feed_shuffle),
                                actionIcon = Icons.Filled.Shuffle,
                                onActionClick = {
                                    state.feedData.mixes.randomOrNull()?.let(viewModel::playMix)
                                },
                            )
                            FeedMediaRow(
                                content = {
                                    items(state.feedData.mixes, key = { it.seed.videoId }) { mix ->
                                        FeedPlaylistCard(
                                            title = mix.title,
                                            subtitle = stringResource(R.string.feed_endless_radio),
                                            artworkUrl = mix.seed.artworkUrl,
                                            onClick = { viewModel.playMix(mix) },
                                            onPlayClick = { viewModel.playMix(mix) },
                                        )
                                    }
                                },
                            )
                        
                                }
                            }
                        }
                    }

                    if (showSynthetic && isSectionVisible(HomeSection.SPOTLIGHT)) {
                    state.feedData.spotlight?.let { spotlight ->
                        item(key = "spotlight_hero") {
                            SpotlightHeroCard(
                                spotlight = spotlight,
                                onPlayRadio = {
                                    viewModel.playArtistRadio(FeedArtist(ArtistHelper.primaryArtist(spotlight.artistName), spotlight.browseId, spotlight.artworkUrl))
                                },
                                onOpenArtist = {
                                    artistAlbumNavigator.openArtist(ArtistHelper.primaryArtist(spotlight.artistName), spotlight.browseId ?: "")
                                },
                            )
                        }
                    }
                    }

                    if (showSynthetic && isSectionVisible(HomeSection.TOP_ARTISTS) && individualTopArtists.isNotEmpty()) {
                        item(key = "top_artists") {
                            Surface(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                                shape = RoundedCornerShape(24.dp),
                                color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.5f),
                            ) {
                                Column(modifier = Modifier.padding(vertical = 12.dp)) {
                            FeedSectionHeader(
                                    title = stringResource(R.string.feed_artists),
                                    subtitle = stringResource(R.string.feed_artists_sub),
                                )
                                LazyRow(
                                    contentPadding = PaddingValues(horizontal = 16.dp),
                                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                                    modifier = Modifier.padding(top = 12.dp),
                                ) {
                                    itemsIndexed(individualTopArtists) { index, artist ->
                                        ArtistAvatarCard(
                                            artist = artist,
                                            isTop = index < 3,
                                            onClick = {
                                                artistAlbumNavigator.openArtist(
                                                    name = ArtistHelper.primaryArtist(artist.name),
                                                    browseId = artist.browseId ?: "",
                                                )
                                            },
                                        )
                                    }
                                }
                            
                                }
                            }
                        }
                        }

                    if (showSynthetic && isSectionVisible(HomeSection.HEAVY_ROTATION) && state.feedData.heavyRotation.isNotEmpty()) {
                        item(key = "heavy_rotation") {
                            Surface(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                                shape = RoundedCornerShape(24.dp),
                                color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.5f),
                            ) {
                                Column(modifier = Modifier.padding(vertical = 12.dp)) {
                            FeedSectionHeader(
                                title = stringResource(R.string.feed_favorites),
                                subtitle = stringResource(R.string.feed_favorites_sub),
                                actionText = stringResource(R.string.feed_play_all),
                                actionIcon = Icons.Filled.PlayArrow,
                                onActionClick = { viewModel.playGeneratedQueue(state.feedData.heavyRotation, 0, "Heavy Rotation") },
                            )
                            FeedMediaRow(
                                content = {
                                    itemsIndexed(state.feedData.heavyRotation) { index, track ->
                                        FeedMediaCard(
                                            title = track.name,
                                            subtitle = ArtistHelper.primaryArtist(track.artist),
                                            artworkUrl = track.artworkUrl,
                                            fallbackIcon = Icons.Filled.MusicNote,
                                            onClick = { viewModel.playGeneratedQueue(state.feedData.heavyRotation, index, "Heavy Rotation") },
                                            onLongClick = {
                                                miniTrayTrack = TrackMiniTrayData(
                                                    title = track.name,
                                                    artist = track.artist,
                                                    artworkUrl = track.artworkUrl,
                                                    sourceLabel = "Home",
                                                    onPlay = { viewModel.playGeneratedQueue(state.feedData.heavyRotation, index, "Heavy Rotation") },
                                                )
                                            },
                                            onPlayClick = { viewModel.playGeneratedQueue(state.feedData.heavyRotation, index, "Heavy Rotation") },
                                        )
                                    }
                                },
                            )
                        
                                }
                            }
                        }
                    }

                    if (showSynthetic && isSectionVisible(HomeSection.ALBUMS) && state.feedData.recentAlbums.isNotEmpty()) {
                        item(key = "albums_in_rotation") {
                            Surface(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                                shape = RoundedCornerShape(24.dp),
                                color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.5f),
                            ) {
                                Column(modifier = Modifier.padding(vertical = 12.dp)) {
                            FeedSectionHeader(
                                title = stringResource(R.string.feed_albums),
                                subtitle = stringResource(R.string.feed_albums_sub),
                            )
                            FeedMediaRow(
                                content = {
                                    items(state.feedData.recentAlbums) { album ->
                                        FeedMediaCard(
                                            title = album.title,
                                            subtitle = ArtistHelper.primaryArtist(album.artist),
                                            artworkUrl = album.artworkUrl,
                                            fallbackIcon = Icons.Filled.Album,
                                            onClick = {
                                                artistAlbumNavigator.openAlbum(
                                                    title = album.title,
                                                    artist = ArtistHelper.primaryArtist(album.artist),
                                                    browseId = album.browseId ?: "",
                                                )
                                            },
                                        )
                                    }
                                },
                            )
                        
                                }
                            }
                        }
                    }

                    if (showSynthetic && isSectionVisible(HomeSection.CHARTS) && state.feedData.charts.isNotEmpty()) {
                        item(key = "trending_charts") {
                            Surface(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                                shape = RoundedCornerShape(24.dp),
                                color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.5f),
                            ) {
                                Column(modifier = Modifier.padding(vertical = 12.dp)) {
                            FeedSectionHeader(
                                title = stringResource(R.string.feed_trending),
                                subtitle = stringResource(R.string.feed_trending_sub),
                                actionText = stringResource(R.string.feed_play_all),
                                actionIcon = Icons.Filled.PlayArrow,
                                onActionClick = { viewModel.playTracksQueue(state.feedData.charts, 0, "Top Charts") },
                                onShuffleClick = { viewModel.shuffleTracksQueue(state.feedData.charts, "Top Charts") },
                            )
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.padding(top = 12.dp),
                            ) {
                                itemsIndexed(state.feedData.charts.take(15)) { index, track ->
                                    ChartTrackCard(
                                        rank = index + 1,
                                        track = track,
                                        onClick = { viewModel.playTrack(track, "Top Charts") },
                                        onLongClick = {
                                            miniTrayTrack = TrackMiniTrayData(
                                                title = track.title,
                                                artist = track.artist,
                                                album = track.album,
                                                artworkUrl = track.artworkUrl,
                                                videoId = track.videoId.takeIf(String::isNotBlank),
                                                sourceLabel = "Home",
                                                onPlay = { viewModel.playTrack(track, "Top Charts") },
                                            )
                                        },
                                    )
                                }
                            }
                        
                                }
                            }
                        }
                    }

                    if (showSynthetic && isSectionVisible(HomeSection.NEW_RELEASES) && state.feedData.newReleases.isNotEmpty()) {
                        item(key = "new_releases") {
                            Surface(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                                shape = RoundedCornerShape(24.dp),
                                color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.5f),
                            ) {
                                Column(modifier = Modifier.padding(vertical = 12.dp)) {
                            FeedSectionHeader(
                                title = stringResource(R.string.feed_releases),
                                subtitle = stringResource(R.string.feed_releases_sub),
                                actionText = stringResource(R.string.feed_see_all),
                                actionIcon = Icons.AutoMirrored.Filled.ArrowForwardIos,
                                onActionClick = onOpenNewReleases,
                            )
                            FeedMediaRow(
                                content = {
                                    items(state.feedData.newReleases) { summary ->
                                        FeedMediaCard(
                                            title = summary.title,
                                            subtitle = summary.author?.let(ArtistHelper::primaryArtist) ?: "Album",
                                            artworkUrl = summary.artworkUrl,
                                            fallbackIcon = Icons.Filled.NewReleases,
                                            badgeText = "NEW",
                                            onClick = {
                                                artistAlbumNavigator.openAlbum(
                                                    title = summary.title,
                                                    artist = summary.author?.let(ArtistHelper::primaryArtist) ?: "",
                                                    browseId = summary.id,
                                                )
                                            },
                                        )
                                    }
                                },
                            )
                        
                                }
                            }
                        }
                    }

                    if (!state.isChipActive) {
                        for ((shelfIndex, shelf) in state.pagedShelves.withIndex()) {
                            if (shelf.items.isEmpty()) continue
                            item(key = "paged_shelf_${shelfIndex}_${shelf.title}") {
                                HomeShelfCard(
                                    shelf = shelf,
                                    onPlayTrack = { track, title -> viewModel.playTrack(track, title) },
                                    onPlayTracksQueue = { tracks, idx, title -> viewModel.playTracksQueue(tracks, idx, title) },
                                    onShuffleTracksQueue = { tracks, title -> viewModel.shuffleTracksQueue(tracks, title) },
                                    onOpenFeedPlaylist = onOpenFeedPlaylist,
                                    onOpenAlbum = { title, artist, id -> artistAlbumNavigator.openAlbum(title, artist, id) },
                                    onTrackLongClick = { tray -> miniTrayTrack = tray },
                                )
                            }
                        }
                    }

                    if (state.isLoadingMore) {
                        item(key = "loading_more_indicator", contentType = "loading") {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                contentAlignment = Alignment.Center,
                            ) {
                                ExpressiveInlineLoadingIndicator()
                            }
                        }
                    }

                    if (showSynthetic) {
                        item(key = "feed_footer") {
                            FeedFooter(lastUpdatedMillis = state.feedData.lastUpdatedMillis)
                        }
                    }
                }
            }
        }
    }
        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter)
                .adaptiveContentWidth(maxWidth = 600.dp)
                .safeHorizontalContentPadding()
                .padding(bottom = FloatingNavDefaults.contentBottomPadding()),
        )
    }


    menuTrack?.let { track ->
        TrackContextMenuSheet(
            target = TrackMenuTarget.Track(track.title, track.artist, ""),
            capabilities = TrackMenuCapabilities(showCopyActions = false, showDeleteScrobble = false),
            playableTrack = PlayableTrack(
                title = track.title,
                artist = track.artist,
                album = track.album,
                artworkUrl = track.artworkUrl,
                videoId = track.videoId.takeIf(String::isNotBlank),
            ),
            playbackSourceLabel = "Home",
            onDismiss = { menuTrack = null },
        )
    }

    miniTrayTrack?.let { tray ->
        TrackMiniTraySheet(
            data = tray,
            onDismiss = { miniTrayTrack = null },
        )
    }
}

private fun String.displayName(): String =
    split(" ", "-", "_").filter { it.isNotBlank() }.joinToString(" ") {
        it.replaceFirstChar { c -> c.uppercase() }
    }

private fun relativeTime(context: android.content.Context, uts: String?): String? {
    val epoch = uts?.toLongOrNull() ?: return null
    val now = System.currentTimeMillis() / 1000
    val diff = (now - epoch).coerceAtLeast(0)
    return when {
        diff < 3600 -> context.getString(R.string.feed_ago_min, (diff / 60).coerceAtLeast(1).toInt())
        diff < 86400 -> context.getString(R.string.feed_ago_hour, (diff / 3600).toInt())
        diff < 86400 * 7 -> context.getString(R.string.feed_ago_day, (diff / 86400).toInt())
        diff < 86400 * 30 -> context.getString(R.string.feed_ago_week, (diff / (86400 * 7)).toInt())
        else -> context.getString(R.string.feed_ago_month, (diff / (86400 * 30)).toInt())
    }
}

@Composable
private fun InfiniteRadioHero(
    quickPicks: List<YouTubeMusicTrack>,
    onPlay: () -> Unit,
) {
    val haptics = LocalHapticFeedback.current
    val heroArt = quickPicks.firstOrNull { !it.artworkUrl.isNullOrBlank() }?.artworkUrl
    val heroShape = RoundedCornerShape(28.dp)
    Surface(
        shape = heroShape,
        color = MaterialTheme.colorScheme.surfaceContainer,
        tonalElevation = 2.dp,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            if (!heroArt.isNullOrBlank()) {
                AsyncImage(
                    model = heroArt,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(208.dp)
                        .alpha(0.32f),
                )
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(208.dp)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.22f),
                                MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.55f),
                                MaterialTheme.colorScheme.surfaceContainer,
                            ),
                        ),
                    ),
            )
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f),
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp),
                        ) {
                            Icon(
                                Icons.Filled.AutoAwesome,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(12.dp),
                            )
                            Text(
                                "MADE FOR YOU",
                                style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.1.sp),
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                            )
                        }
                    }
                }
                Text(
                    text = "Infinite Radio",
                    style = MaterialTheme.typography.headlineSmall.copy(fontSize = 24.sp, letterSpacing = (-0.4).sp),
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.semantics { heading() },
                )
                Text(
                    text = "An endless station shaped by your listening",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(2.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Button(
                        onClick = {
                            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                            onPlay()
                        },
                        enabled = quickPicks.isNotEmpty(),
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary,
                        ),
                        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp),
                        modifier = Modifier.height(44.dp),
                    ) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.feed_play_cd), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun TasteStrip(
    tags: List<String>,
    launching: String?,
    onTagClick: (String) -> Unit,
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        FeedSectionHeader(
            title = stringResource(R.string.feed_your_sound),
            subtitle = stringResource(R.string.feed_your_sound_sub),
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(top = 10.dp),
        ) {
            items(tags, key = { it }) { tag ->
                val isLoading = launching?.equals(tag.displayName(), ignoreCase = true) == true
                Surface(
                    onClick = { onTagClick(tag) },
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.85f),
                    modifier = Modifier,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.18f),
                    ),
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(7.dp),
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                        )
                        Text(
                            tag.displayName(),
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        if (isLoading) {
                            Icon(
                                Icons.Filled.Refresh,
                                contentDescription = stringResource(R.string.feed_start_radio_cd),
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(14.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Horizontally scrolling row of YouTube Music mood/activity chips
 * (e.g., Relax, Energize, Workout, Commute, Focus).
 * Placed directly above the native YTM shelves using the app's liquid-glass style.
 * Adapted from Metrolist's Home screen chip row (GPL-3.0).
 */
@Composable
fun HomeChipsRow(
    chips: List<HomeChip>,
    selectedChip: HomeChip?,
    onChipClick: (HomeChip) -> Unit,
    modifier: Modifier = Modifier,
) {
    if (chips.isEmpty()) return
    val haptics = LocalHapticFeedback.current
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = modifier.fillMaxWidth(),
    ) {
        items(chips, key = { it.title }) { chip ->
            val isSelected = chip == selectedChip
            Surface(
                onClick = {
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    onChipClick(chip)
                },
                shape = CircleShape,
                color = if (isSelected) {
                    MaterialTheme.colorScheme.primary
                } else {
                    MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.85f)
                },
                border = BorderStroke(
                    width = 1.dp,
                    color = if (isSelected) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.22f)
                    },
                ),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = chip.title,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) {
                            MaterialTheme.colorScheme.onPrimary
                        } else {
                            MaterialTheme.colorScheme.onSurface
                        },
                    )
                }
            }
        }
    }
}

/**
 * Pinned container for the YTM chip row. Sits directly under the app bar and
 * stays visible while the feed scrolls, with a subtle gradient scrim behind
 * it so content sliding underneath stays legible. Liquid-glass styled.
 */
@Composable
private fun PinnedChipsBar(
    chips: List<HomeChip>,
    selectedChip: HomeChip?,
    onChipClick: (HomeChip) -> Unit,
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    0f to MaterialTheme.colorScheme.background.copy(alpha = 0.96f),
                    0.7f to MaterialTheme.colorScheme.background.copy(alpha = 0.82f),
                    1f to MaterialTheme.colorScheme.background.copy(alpha = 0f),
                )
            ),
    ) {
        HomeChipsRow(
            chips = chips,
            selectedChip = selectedChip,
            onChipClick = onChipClick,
            modifier = Modifier.padding(top = 4.dp, bottom = 10.dp),
        )
    }
}

/**
 * Reusable surface card for a YouTube Music carousel shelf.
 * Renders each item through the card system (square / wide / featured /
 * community) chosen from the item's real YTM data, falling back to square.
 * Used for page-1 native shelves, continuation paged shelves, and chip shelves.
 */
@Composable
private fun HomeShelfCard(
    shelf: HomeShelf,
    onPlayTrack: (YouTubeMusicTrack, String) -> Unit,
    onPlayTracksQueue: (List<YouTubeMusicTrack>, Int, String) -> Unit,
    onShuffleTracksQueue: (List<YouTubeMusicTrack>, String) -> Unit,
    onOpenFeedPlaylist: (String) -> Unit,
    onOpenAlbum: (title: String, artist: String, browseId: String) -> Unit,
    onTrackLongClick: (TrackMiniTrayData) -> Unit,
    modifier: Modifier = Modifier,
) {
    if (shelf.items.isEmpty()) return
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.5f),
    ) {
        Column(modifier = Modifier.padding(vertical = 12.dp)) {
            val tracksInShelf = remember(shelf.items) {
                shelf.items.mapNotNull { (it as? HomeShelfItem.Track)?.track }
            }
            // "More" only when the shelf's destination is a playlist/album id
            // the app already knows how to open; mood/genre/chart browse ids
            // aren't supported surfaces, so the chevron stays hidden for them.
            val morePlaylistId = remember(shelf.moreBrowseId) {
                shelf.moreBrowseId
                    ?.removePrefix("VL")
                    ?.takeIf { it.startsWith("PL") || it.startsWith("MPRE") || it.startsWith("RD") || it.startsWith("OLAK") }
            }
            com.lastwave.app.ui.feed.cards.ShelfHeaderV2(
                title = shelf.title,
                eyebrow = shelf.strapline,
                subtitle = shelf.subtitle,
                showMore = morePlaylistId != null,
                onMoreClick = morePlaylistId?.let { { onOpenFeedPlaylist(it) } },
                onPlayAll = if (tracksInShelf.isNotEmpty()) {
                    { onPlayTracksQueue(tracksInShelf, 0, shelf.title) }
                } else null,
                onShuffle = if (tracksInShelf.isNotEmpty()) {
                    { onShuffleTracksQueue(tracksInShelf, shelf.title) }
                } else null,
            )
            FeedMediaRow(
                content = {
                    itemsIndexed(
                        shelf.items,
                        key = { _, item ->
                            when (item) {
                                is HomeShelfItem.Track -> "t_${item.track.videoId}"
                                is HomeShelfItem.Playlist -> "p_${item.playlist.id}"
                            }
                        },
                    ) { _, shelfItem ->
                        Box(Modifier.animateItem()) {
                            NativeShelfItemCard(
                                shelfItem = shelfItem,
                                shelfTitle = shelf.title,
                                onPlayTrack = onPlayTrack,
                                onOpenFeedPlaylist = onOpenFeedPlaylist,
                                onOpenAlbum = onOpenAlbum,
                                onTrackLongClick = onTrackLongClick,
                            )
                        }
                    }
                },
            )
        }
    }
}

/**
 * Dispatches a single shelf item to its card variant based on the real YTM
 * data (aspect ratio, caption, community preview songs). Unknown shapes fall
 * back to the square card. Calls the same play/open/menu handlers as before.
 */
@Composable
private fun NativeShelfItemCard(
    shelfItem: HomeShelfItem,
    shelfTitle: String,
    onPlayTrack: (YouTubeMusicTrack, String) -> Unit,
    onOpenFeedPlaylist: (String) -> Unit,
    onOpenAlbum: (title: String, artist: String, browseId: String) -> Unit,
    onTrackLongClick: (TrackMiniTrayData) -> Unit,
) {
    when (val variant = com.lastwave.app.ui.feed.cards.selectCardVariant(shelfItem)) {
        com.lastwave.app.ui.feed.cards.HomeCardVariant.WIDE -> WideItemCard(
            shelfItem = shelfItem,
            shelfTitle = shelfTitle,
            onPlayTrack = onPlayTrack,
            onOpenFeedPlaylist = onOpenFeedPlaylist,
            onOpenAlbum = onOpenAlbum,
            onTrackLongClick = onTrackLongClick,
        )
        com.lastwave.app.ui.feed.cards.HomeCardVariant.FEATURED -> FeaturedItemCard(
            shelfItem = shelfItem,
            shelfTitle = shelfTitle,
            onPlayTrack = onPlayTrack,
            onOpenFeedPlaylist = onOpenFeedPlaylist,
            onOpenAlbum = onOpenAlbum,
            onTrackLongClick = onTrackLongClick,
        )
        com.lastwave.app.ui.feed.cards.HomeCardVariant.COMMUNITY -> {
            val item = shelfItem as? HomeShelfItem.Playlist ?: return
            CommunityItemCard(
                item = item,
                shelfTitle = shelfTitle,
                onPlayTrack = onPlayTrack,
                onOpenFeedPlaylist = onOpenFeedPlaylist,
                onOpenAlbum = onOpenAlbum,
                onTrackLongClick = onTrackLongClick,
            )
        }
        else -> SquareItemCard(
            shelfItem = shelfItem,
            shelfTitle = shelfTitle,
            onPlayTrack = onPlayTrack,
            onOpenFeedPlaylist = onOpenFeedPlaylist,
            onOpenAlbum = onOpenAlbum,
            onTrackLongClick = onTrackLongClick,
        )
    }
}

/** Builds the track mini-tray payload used by every card's long-press. */
private fun trackTray(track: YouTubeMusicTrack, shelfTitle: String, onPlayTrack: (YouTubeMusicTrack, String) -> Unit) =
    TrackMiniTrayData(
        title = track.title,
        artist = track.artist,
        album = track.album,
        artworkUrl = track.artworkUrl,
        videoId = track.videoId.takeIf(String::isNotBlank),
        sourceLabel = "Home",
        onPlay = { onPlayTrack(track, shelfTitle) },
    )

private fun playlistInfoLine(p: com.lastwave.app.data.music.YouTubePlaylistSummary): String =
    listOfNotNull(
        p.author,
        p.trackCountText,
    ).joinToString(" • ").ifBlank { p.author.orEmpty() }

private fun openPlaylistOrAlbum(
    playlist: com.lastwave.app.data.music.YouTubePlaylistSummary,
    onOpenFeedPlaylist: (String) -> Unit,
    onOpenAlbum: (title: String, artist: String, browseId: String) -> Unit,
) {
    if (playlist.id.startsWith("MPRE")) {
        onOpenAlbum(playlist.title, playlist.author.orEmpty(), playlist.id)
    } else {
        onOpenFeedPlaylist(playlist.id)
    }
}

@Composable
private fun SquareItemCard(
    shelfItem: HomeShelfItem,
    shelfTitle: String,
    onPlayTrack: (YouTubeMusicTrack, String) -> Unit,
    onOpenFeedPlaylist: (String) -> Unit,
    onOpenAlbum: (title: String, artist: String, browseId: String) -> Unit,
    onTrackLongClick: (TrackMiniTrayData) -> Unit,
) {
    when (shelfItem) {
        is HomeShelfItem.Track -> {
            val track = shelfItem.track
            com.lastwave.app.ui.feed.cards.ShelfSquareCard(
                title = track.title,
                infoLine = ArtistHelper.primaryArtist(track.artist),
                artworkUrl = track.artworkUrl,
                fallbackIcon = Icons.Filled.MusicNote,
                onClick = { onPlayTrack(track, shelfTitle) },
                onLongClick = { onTrackLongClick(trackTray(track, shelfTitle, onPlayTrack)) },
                onPlayClick = { onPlayTrack(track, shelfTitle) },
                cardWidth = com.lastwave.app.ui.feed.cards.rememberSquareCardWidth(),
            )
        }
        is HomeShelfItem.Playlist -> {
            val p = shelfItem.playlist
            com.lastwave.app.ui.feed.cards.ShelfSquareCard(
                title = p.title,
                infoLine = playlistInfoLine(p),
                artworkUrl = p.artworkUrl,
                fallbackIcon = Icons.AutoMirrored.Filled.QueueMusic,
                onClick = { openPlaylistOrAlbum(p, onOpenFeedPlaylist, onOpenAlbum) },
                cardWidth = com.lastwave.app.ui.feed.cards.rememberSquareCardWidth(),
            )
        }
    }
}

@Composable
private fun WideItemCard(
    shelfItem: HomeShelfItem,
    shelfTitle: String,
    onPlayTrack: (YouTubeMusicTrack, String) -> Unit,
    onOpenFeedPlaylist: (String) -> Unit,
    onOpenAlbum: (title: String, artist: String, browseId: String) -> Unit,
    onTrackLongClick: (TrackMiniTrayData) -> Unit,
) {
    when (shelfItem) {
        is HomeShelfItem.Track -> {
            val track = shelfItem.track
            com.lastwave.app.ui.feed.cards.ShelfWideCard(
                title = track.title,
                infoLine = ArtistHelper.primaryArtist(track.artist),
                artworkUrl = track.artworkUrl,
                onClick = { onPlayTrack(track, shelfTitle) },
                onLongClick = { onTrackLongClick(trackTray(track, shelfTitle, onPlayTrack)) },
                onPlayClick = { onPlayTrack(track, shelfTitle) },
                cardWidth = com.lastwave.app.ui.feed.cards.rememberWideCardWidth(),
            )
        }
        is HomeShelfItem.Playlist -> {
            val p = shelfItem.playlist
            com.lastwave.app.ui.feed.cards.ShelfWideCard(
                title = p.title,
                infoLine = playlistInfoLine(p),
                artworkUrl = p.artworkUrl,
                fallbackIcon = Icons.AutoMirrored.Filled.QueueMusic,
                onClick = { openPlaylistOrAlbum(p, onOpenFeedPlaylist, onOpenAlbum) },
                cardWidth = com.lastwave.app.ui.feed.cards.rememberWideCardWidth(),
            )
        }
    }
}

@Composable
private fun FeaturedItemCard(
    shelfItem: HomeShelfItem,
    shelfTitle: String,
    onPlayTrack: (YouTubeMusicTrack, String) -> Unit,
    onOpenFeedPlaylist: (String) -> Unit,
    onOpenAlbum: (title: String, artist: String, browseId: String) -> Unit,
    onTrackLongClick: (TrackMiniTrayData) -> Unit,
) {
    when (shelfItem) {
        is HomeShelfItem.Track -> {
            val track = shelfItem.track
            com.lastwave.app.ui.feed.cards.ShelfFeaturedCard(
                title = track.title,
                artist = ArtistHelper.primaryArtist(track.artist),
                artworkUrl = track.artworkUrl,
                caption = shelfItem.caption,
                onClick = { onPlayTrack(track, shelfTitle) },
                onLongClick = { onTrackLongClick(trackTray(track, shelfTitle, onPlayTrack)) },
                cardWidth = com.lastwave.app.ui.feed.cards.rememberFeaturedCardWidth(),
            )
        }
        is HomeShelfItem.Playlist -> {
            val p = shelfItem.playlist
            com.lastwave.app.ui.feed.cards.ShelfFeaturedCard(
                title = p.title,
                artist = playlistInfoLine(p),
                artworkUrl = p.artworkUrl,
                caption = shelfItem.caption,
                fallbackIcon = Icons.AutoMirrored.Filled.QueueMusic,
                onClick = { openPlaylistOrAlbum(p, onOpenFeedPlaylist, onOpenAlbum) },
                cardWidth = com.lastwave.app.ui.feed.cards.rememberFeaturedCardWidth(),
            )
        }
    }
}

@Composable
private fun CommunityItemCard(
    item: HomeShelfItem.Playlist,
    shelfTitle: String,
    onPlayTrack: (YouTubeMusicTrack, String) -> Unit,
    onOpenFeedPlaylist: (String) -> Unit,
    onOpenAlbum: (title: String, artist: String, browseId: String) -> Unit,
    onTrackLongClick: (TrackMiniTrayData) -> Unit,
) {
    val p = item.playlist
    com.lastwave.app.ui.feed.cards.ShelfCommunityPlaylistCard(
        title = p.title,
        subtitle = playlistInfoLine(p),
        collageUrls = item.collageArtworkUrls,
        songs = item.previewSongs,
        artworkUrl = p.artworkUrl,
        onClick = { openPlaylistOrAlbum(p, onOpenFeedPlaylist, onOpenAlbum) },
        onPlayClick = {
            if (item.previewSongs.isNotEmpty()) {
                onPlayTrack(item.previewSongs.first(), p.title)
            } else {
                openPlaylistOrAlbum(p, onOpenFeedPlaylist, onOpenAlbum)
            }
        },
        onSongClick = { onPlayTrack(it, p.title) },
        onSongMenuClick = { onTrackLongClick(trackTray(it, p.title, onPlayTrack)) },
        cardWidth = com.lastwave.app.ui.feed.cards.rememberCommunityCardWidth(),
    )
}

@Composable
private fun FeedLoadingSkeleton() {
    val transition = rememberInfiniteTransition(label = "feedSkeleton")
    val pulse by transition.animateFloat(
        initialValue = 0.45f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(900), repeatMode = RepeatMode.Reverse),
        label = "skeletonPulse",
    )
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            bottom = FloatingNavDefaults.contentBottomPadding(),
            top = 12.dp,
        ),
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .height(208.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.7f * pulse + 0.3f)),
            )
        }
        item {
            Column(
                modifier = Modifier.padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                repeat(2) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        repeat(2) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(64.dp)
                                    .clip(RoundedCornerShape(18.dp))
                                    .background(MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.7f * pulse + 0.3f)),
                            )
                        }
                    }
                }
            }
        }
        items(3) { row ->
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    modifier = Modifier
                        .padding(horizontal = 18.dp)
                        .width((140 + row * 30).dp)
                        .height(20.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.7f * pulse + 0.3f)),
                )
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    userScrollEnabled = false,
                ) {
                    items(4) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(148.dp)
                                    .clip(RoundedCornerShape(18.dp))
                                    .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.7f * pulse + 0.3f)),
                            )
                            Box(
                                modifier = Modifier
                                    .width(110.dp)
                                    .height(12.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.7f * pulse + 0.3f)),
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FeedFooter(lastUpdatedMillis: Long) {
    val context = LocalContext.current
    val label = remember(lastUpdatedMillis) {
        if (lastUpdatedMillis <= 0L) context.getString(R.string.feed_footer_default)
        else try {
            val time = java.time.Instant.ofEpochMilli(lastUpdatedMillis)
                .atZone(java.time.ZoneId.systemDefault())
                .format(java.time.format.DateTimeFormatter.ofPattern("h:mm a"))
            context.getString(R.string.feed_footer_updated, time)
        } catch (_: Exception) {
            context.getString(R.string.feed_footer_default)
        }
    }
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 4.dp, bottom = 4.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
            textAlign = TextAlign.Center,
        )
    }
}



@Composable
private fun QuickTilesGrid(
    tiles: List<FeedQuickTile>,
    onTileClick: (FeedQuickTile) -> Unit,
) {
    androidx.compose.foundation.lazy.LazyRow(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        items(tiles) { tile ->
            QuickTileCard(
                tile = tile,
                onClick = { onTileClick(tile) },
            )
        }
    }
}

@Composable
private fun QuickTileCard(
    tile: FeedQuickTile,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val tileShape = RoundedCornerShape(18.dp)

    // Per-type vibrant gradient pairs for the artwork/icon box matching modern expressive designs
    val isLiveMapTile = tile.collection == "live_map"
    val isYtLikedTile = tile.collection == "yt_liked" || tile.playlistId == "yt_liked"
    val isLocalLikedTile = tile.isLiked && !isYtLikedTile
    val isLikedTile = isYtLikedTile || isLocalLikedTile
    val isMixTile = tile.collection == "mix" || tile.collection == "discover_mix" || tile.title.contains("Discover Mix", ignoreCase = true)
    val isMyMixTile = tile.collection == "my_mix" || tile.title.equals("My Mix", ignoreCase = true)
    val isDiscoverTile = tile.collection == "radio" || tile.title.equals("Discover", ignoreCase = true)
    val isNewReleasesTile = tile.collection == "new_releases"

    val iconGradient = when {
        isLiveMapTile -> Brush.linearGradient(
            colors = listOf(MaterialTheme.colorScheme.tertiaryContainer, MaterialTheme.colorScheme.tertiary),
        )
        isLikedTile -> Brush.linearGradient(
            colors = listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.primary),
        )
        isMixTile -> Brush.linearGradient(
            colors = listOf(MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.secondary),
        )
        isMyMixTile -> Brush.linearGradient(
            colors = listOf(MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)),
        )
        isDiscoverTile -> Brush.linearGradient(
            colors = listOf(MaterialTheme.colorScheme.tertiaryContainer, MaterialTheme.colorScheme.tertiary),
        )
        isNewReleasesTile -> Brush.linearGradient(
            colors = listOf(MaterialTheme.colorScheme.errorContainer, MaterialTheme.colorScheme.error),
        )
        else -> Brush.linearGradient(
            colors = listOf(
                MaterialTheme.colorScheme.primaryContainer,
                MaterialTheme.colorScheme.surfaceContainerHighest,
            ),
        )
    }

    Surface(
        onClick = onClick,
        shape = tileShape,
        color = when {
            isLiveMapTile -> MaterialTheme.colorScheme.tertiaryContainer
            isLikedTile -> MaterialTheme.colorScheme.primaryContainer
            isMixTile -> MaterialTheme.colorScheme.secondaryContainer
            isMyMixTile -> MaterialTheme.colorScheme.surfaceVariant
            isDiscoverTile -> MaterialTheme.colorScheme.tertiaryContainer
            isNewReleasesTile -> MaterialTheme.colorScheme.errorContainer
            else -> MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.75f)
        },
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.10f),
        ),
        modifier = modifier
            .width(136.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp),
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(iconGradient),
                contentAlignment = Alignment.Center,
            ) {
                if (isLiveMapTile) {
                    Icon(
                        Icons.Filled.Public,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onTertiaryContainer,
                        modifier = Modifier.size(36.dp),
                    )
                } else if (isYtLikedTile) {
                    Icon(
                        Icons.Filled.ThumbUp,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(36.dp),
                    )
                } else if (isLocalLikedTile) {
                    Icon(
                        Icons.Filled.Favorite,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(36.dp),
                    )
                } else if (isMixTile) {
                    Icon(
                        Icons.Filled.AutoAwesome,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.size(36.dp),
                    )
                } else if (isMyMixTile) {
                    Icon(
                        Icons.Filled.AllInclusive,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(36.dp),
                    )
                } else if (isDiscoverTile) {
                    Icon(
                        Icons.Filled.Explore,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onTertiaryContainer,
                        modifier = Modifier.size(36.dp),
                    )
                } else if (isNewReleasesTile) {
                    Icon(
                        Icons.Filled.NewReleases,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.size(36.dp),
                    )
                } else {
                    ArtworkImage(
                        name = tile.title,
                        artist = tile.subtitle ?: "",
                        embeddedUrl = tile.artworkUrl,
                        fallbackIcon = Icons.Filled.Album,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, start = 2.dp, end = 2.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Text(
                    text = tile.title,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontSize = 13.sp,
                        lineHeight = 16.sp,
                        fontWeight = FontWeight.Bold,
                    ),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                val finalSubtitle = if (isNewReleasesTile) "Fresh drops" else tile.subtitle ?: if (tile.actionVideoId != null) "Track" else "Playlist"
                if (finalSubtitle.isNotEmpty()) {
                    Text(
                        text = finalSubtitle,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontSize = 11.sp,
                            lineHeight = 14.sp,
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun QuickPicksRows(
    tracks: List<YouTubeMusicTrack>,
    currentPlayingVideoId: String?,
    isPlaying: Boolean,
    onTrackClick: (Int) -> Unit,
    onMenuClick: (YouTubeMusicTrack) -> Unit,
    onLongClick: (YouTubeMusicTrack, Int) -> Unit = { _, _ -> },
) {
    val sizeClass = rememberWindowSizeClass()
    val haptics = LocalHapticFeedback.current
    val widthFraction = when (sizeClass) {
        WindowSizeClass.COMPACT -> 0.88f
        WindowSizeClass.MEDIUM -> 0.48f
        WindowSizeClass.EXPANDED -> 0.32f
    }
    val columns = remember(tracks) { tracks.chunked(3) }
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.padding(top = 12.dp),
    ) {
        itemsIndexed(columns) { columnIndex, column ->
            Column(
                modifier = Modifier.fillParentMaxWidth(widthFraction),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                column.forEachIndexed { rowIndex, track ->
                    val overallIndex = columnIndex * 3 + rowIndex
                    val isCurrent = track.videoId.isNotBlank() && track.videoId == currentPlayingVideoId
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = if (isCurrent) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                        else MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.65f),
                        border = null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .combinedClickable(
                                onClick = { onTrackClick(overallIndex) },
                                onLongClick = {
                                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                    onLongClick(track, overallIndex)
                                },
                            ),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            Box(modifier = Modifier.size(48.dp)) {
                                ArtworkImage(
                                    name = track.title,
                                    artist = ArtistHelper.primaryArtist(track.artist),
                                    embeddedUrl = track.artworkUrl,
                                    fallbackIcon = Icons.Filled.MusicNote,
                                    modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp)),
                                )
                                if (isCurrent && isPlaying) {
                                    PlayingWaveBars(
                                        modifier = Modifier
                                            .align(Alignment.BottomEnd)
                                            .padding(2.dp)
                                            .size(24.dp, 18.dp),
                                    )
                                }
                            }
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(
                                    track.title,
                                    style = MaterialTheme.typography.bodyLarge.copy(fontSize = 15.5.sp),
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(start = 2.dp),
                                )
                                Text(
                                    ArtistHelper.primaryArtist(track.artist),
                                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(start = 2.dp),
                                )
                            }
                            IconButton(
                                onClick = { onMenuClick(track) },
                                modifier = Modifier.size(36.dp),
                            ) {
                                Icon(
                                    Icons.Filled.MoreVert,
                                    contentDescription = stringResource(R.string.feed_more_cd, track.title),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                    modifier = Modifier.size(20.dp),
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FeedMediaRow(
    content: LazyListScope.() -> Unit,
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(CardTokens.cardGap),
        modifier = Modifier.padding(top = 10.dp),
        content = content,
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FeedMediaCard(
    title: String,
    subtitle: String,
    artworkUrl: String?,
    fallbackIcon: ImageVector,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    onPlayClick: (() -> Unit)? = null,
    badgeText: String? = null,
    cardWidth: androidx.compose.ui.unit.Dp = rememberSquareCardWidth(),
) {
    val haptics = LocalHapticFeedback.current
    val coverHeight = rememberCoverHeight()
    Column(
        modifier = Modifier
            .width(cardWidth)
            .combinedClickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onLongClick = onLongClick,
                onClick = {
                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onClick()
                },
            ),
    ) {
        Box(modifier = Modifier.width(cardWidth).height(coverHeight)) {
            // No onClick here on purpose: the outer Column's combinedClickable
            // owns tap + long-press for the whole card. An inner clickable
            // Surface would swallow the press and starve the long-press tray.
            Surface(
                shape = RoundedCornerShape(CardTokens.coverCornerRadius),
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                tonalElevation = 1.dp,
                modifier = Modifier.fillMaxSize(),
            ) {
                Box(Modifier.fillMaxSize()) {
                    ArtworkImage(
                        name = title,
                        artist = subtitle,
                        embeddedUrl = artworkUrl,
                        fallbackIcon = fallbackIcon,
                        modifier = Modifier.fillMaxSize(),
                    )
                    if (badgeText != null) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(8.dp),
                        ) {
                            Text(
                                badgeText,
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            )
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(CardTokens.coverToTextGap))
        CardTextArea(title = title, infoLine = subtitle)
    }
}

@Composable
private fun FeedPlaylistCard(
    title: String,
    subtitle: String,
    artworkUrl: String?,
    onClick: () -> Unit,
    onPlayClick: (() -> Unit)? = null,
) {
    FeedMediaCard(
        title = title,
        subtitle = subtitle,
        artworkUrl = artworkUrl,
        fallbackIcon = Icons.Filled.Album,
        onClick = onClick,
        onPlayClick = onPlayClick,
        cardWidth = rememberSquareCardWidth(),
    )
}

// Legacy card variants were consolidated into FeedMediaCard / FeedPlaylistCard
// so every shelf shares one artwork, type and play-affordance language.

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun RecentTrackCard(
    track: RecentTrack,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
) {
    val context = LocalContext.current
    val ago = remember(track.date?.uts, track.url) { relativeTime(context, track.date?.uts) }
    val primaryArtistName = remember(track.artist.displayName) { ArtistHelper.primaryArtist(track.artist.displayName) }
    val subtitle = if (ago != null) "$primaryArtistName · $ago" else primaryArtistName
    val haptics = LocalHapticFeedback.current
    val cardWidth = rememberSquareCardWidth()
    val coverHeight = rememberCoverHeight()
    Column(
        modifier = Modifier
            .width(cardWidth)
            .combinedClickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = {
                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onClick()
                },
                onLongClick = onLongClick?.let {
                    {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        it()
                    }
                },
            ),
    ) {
        Surface(
            shape = RoundedCornerShape(CardTokens.coverCornerRadius),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            tonalElevation = 1.dp,
            modifier = Modifier.width(cardWidth).height(coverHeight),
        ) {
            Box(Modifier.fillMaxSize()) {
                ArtworkImage(
                    name = track.name,
                    artist = primaryArtistName,
                    embeddedUrl = track.artworkUrl,
                    fallbackIcon = Icons.Filled.MusicNote,
                    modifier = Modifier.fillMaxSize(),
                )
                if (ago != null) {
                    Surface(
                        shape = CircleShape,
                        color = Color.Black.copy(alpha = 0.62f),
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(8.dp),
                    ) {
                        Text(
                            ago,
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(CardTokens.coverToTextGap))
        CardTextArea(title = track.name, infoLine = subtitle)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ChartTrackCard(
    rank: Int,
    track: YouTubeMusicTrack,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
) {
    val isTop3 = rank <= 3
    val haptics = LocalHapticFeedback.current
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = if (isTop3) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
        else MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.7f),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isTop3) MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
            else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f),
        ),
        modifier = Modifier
            .width(288.dp)
            .height(76.dp)
            .combinedClickable(
                onClick = {
                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onClick()
                },
                onLongClick = onLongClick?.let {
                    {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        it()
                    }
                },
            ),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxSize()
                .padding(start = 14.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
        ) {
            Text(
                text = String.format("%02d", rank),
                style = MaterialTheme.typography.titleLarge.copy(fontSize = 22.sp),
                fontWeight = FontWeight.Black,
                color = if (isTop3) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.55f),
                modifier = Modifier.width(40.dp),
            )
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHighest,
                modifier = Modifier.size(56.dp),
            ) {
                Box(Modifier.fillMaxSize()) {
                    ArtworkImage(
                        name = track.title,
                        artist = ArtistHelper.primaryArtist(track.artist),
                        embeddedUrl = track.artworkUrl,
                        fallbackIcon = Icons.Filled.TrendingUp,
                        modifier = Modifier.fillMaxSize(),
                    )
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(3.dp)
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.55f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            Icons.Filled.PlayArrow,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(14.dp),
                        )
                    }
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text(
                    text = track.title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                    text = ArtistHelper.primaryArtist(track.artist),
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                )
            }
        }
    }
}

@Composable
private fun SpotlightHeroCard(
    spotlight: FeedSpotlight,
    onPlayRadio: () -> Unit,
    onOpenArtist: () -> Unit,
) {
    val primaryArtistName = remember(spotlight.artistName) { ArtistHelper.primaryArtist(spotlight.artistName) }
    val gradientBrush = Brush.linearGradient(
        colors = listOf(
            MaterialTheme.colorScheme.primary.copy(alpha = 0.16f),
            MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.85f),
            MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.95f),
        ),
        start = Offset(0f, 0f),
        end = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY),
    )
    Surface(
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        tonalElevation = 2.dp,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            if (!spotlight.artworkUrl.isNullOrBlank()) {
                AsyncImage(
                    model = spotlight.artworkUrl,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                        .alpha(0.28f),
                )
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(gradientBrush)
                    .padding(20.dp),
            ) {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Icon(
                            Icons.Filled.AutoAwesome,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(12.dp),
                        )
                        Text(
                            "ARTIST SPOTLIGHT",
                            style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.2.sp),
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    Surface(
                        onClick = onOpenArtist,
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.surfaceContainerHighest,
                        modifier = Modifier.size(76.dp),
                    ) {
                        if (!spotlight.artworkUrl.isNullOrBlank()) {
                            AsyncImage(
                                model = spotlight.artworkUrl,
                                contentDescription = stringResource(R.string.feed_open_artist_cd, primaryArtistName),
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize(),
                            )
                        } else {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text(
                                    primaryArtistName.take(1).uppercase(),
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                )
                            }
                        }
                    }

                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            primaryArtistName,
                            style = MaterialTheme.typography.titleLarge.copy(fontSize = 21.sp),
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(start = 2.dp),
                        )
                        spotlight.topTrackTitle?.takeIf(String::isNotBlank)?.let { title ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                            ) {
                                Icon(
                                    Icons.Filled.MusicNote,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                    modifier = Modifier.size(14.dp),
                                )
                                Text(
                                    title,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(start = 2.dp),
                                )
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Button(
                        onClick = onPlayRadio,
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary,
                        ),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                        modifier = Modifier.weight(1f).height(42.dp),
                    ) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.feed_artist_radio), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                    }
                    Surface(
                        onClick = onOpenArtist,
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.8f),
                        modifier = Modifier.weight(1f).height(42.dp),
                    ) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(
                                "View artist",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface,
                            )
                        }
                    }
                }
            }
            }
        }
    }
}

@Composable
private fun ArtistAvatarCard(
    artist: FeedArtist,
    onClick: () -> Unit,
    isTop: Boolean = false,
) {
    val haptics = LocalHapticFeedback.current
    val primaryArtistName = remember(artist.name) { ArtistHelper.primaryArtist(artist.name) }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(100.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = {
                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onClick()
                },
            ),
    ) {
        Box(modifier = Modifier.size(92.dp), contentAlignment = Alignment.Center) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                border = if (isTop) androidx.compose.foundation.BorderStroke(
                    2.dp,
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.75f),
                ) else androidx.compose.foundation.BorderStroke(
                    1.dp,
                    MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
                ),
                shadowElevation = if (isTop) 6.dp else 0.dp,
                modifier = Modifier.size(88.dp),
                onClick = {
                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onClick()
                },
            ) {
                if (!artist.artworkUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = artist.artworkUrl,
                        contentDescription = primaryArtistName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                } else {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            text = primaryArtistName.take(1).uppercase(),
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                }
            }
            if (isTop) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.align(Alignment.BottomEnd),
                ) {
                    Icon(
                        Icons.Filled.Whatshot,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.padding(4.dp).size(12.dp),
                    )
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            text = primaryArtistName,
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp),
            fontWeight = FontWeight.Bold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center,
            lineHeight = 15.sp,
            modifier = Modifier.padding(horizontal = 2.dp),
        )
    }
}

@Composable
private fun FriendAvatarCard(
    friend: FriendEntry,
    onClick: () -> Unit = {},
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(80.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick,
            ),
    ) {
        Surface(
            onClick = onClick,
            shape = CircleShape,
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            modifier = Modifier.size(60.dp),
        ) {
            if (!friend.avatarUrl.isNullOrBlank()) {
                AsyncImage(
                    model = friend.avatarUrl,
                    contentDescription = friend.displayName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = friend.displayName.take(1).uppercase(),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = friend.displayName,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 2.dp),
        )
    }
}

@Composable
private fun FeedSectionHeader(
    title: String,
    subtitle: String? = null,
    actionText: String? = null,
    actionIcon: ImageVector? = null,
    onActionClick: (() -> Unit)? = null,
    onShuffleClick: (() -> Unit)? = null,
) {
    val haptics = LocalHapticFeedback.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .then(
                    if (onActionClick != null) {
                        Modifier.clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = onActionClick,
                        )
                    } else Modifier
                ),
        ) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium.copy(fontSize = 20.sp, letterSpacing = (-0.4).sp),
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .semantics { heading() }
                    .padding(start = 2.dp),
            )
            if (!subtitle.isNullOrBlank()) {
                Spacer(Modifier.height(1.dp))
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(start = 2.dp),
                )
            }
        }
        if (onShuffleClick != null) {
            Surface(
                onClick = {
                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onShuffleClick()
                },
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.7f),
            ) {
                Box(
                    modifier = Modifier.padding(8.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        Icons.Filled.Shuffle,
                        contentDescription = stringResource(R.string.feed_shuffle_title_cd, title),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp),
                    )
                }
            }
        }
        if (actionText != null && onActionClick != null) {
            Surface(
                onClick = {
                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onActionClick()
                },
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 13.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                ) {
                    actionIcon?.let { icon ->
                        Icon(
                            if (icon == Icons.Filled.PlayArrow) Icons.Filled.PlayCircle else icon,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(15.dp),
                        )
                    }
                    Text(
                        actionText,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                }
            }
        }
    }
}

@Composable
private fun FeedEmptyState(
    message: String,
    onRetry: () -> Unit,
    onOpenSearch: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .safeHorizontalContentPadding()
            .verticalScroll(rememberScrollState())
            .padding(bottom = FloatingNavDefaults.contentBottomPadding())
            .padding(horizontal = 32.dp, vertical = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f),
            modifier = Modifier.size(72.dp),
        ) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = Icons.Filled.MusicNote,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(32.dp),
                )
            }
        }
        Spacer(Modifier.height(20.dp))
        Text(
            text = "Find your next favorite",
            style = MaterialTheme.typography.titleMedium.copy(fontSize = 18.sp),
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp),
        )
        Spacer(Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                onClick = onOpenSearch,
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                ),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp),
            ) {
                Icon(Icons.Filled.Search, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(stringResource(R.string.feed_search_music), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
            }
            Surface(
                onClick = onRetry,
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.7f),
                modifier = Modifier,
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        Icons.Filled.Refresh,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        "Try again",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                }
            }
        }
    }
}

@dagger.hilt.android.lifecycle.HiltViewModel
class ArtistAlbumNavBridgeFeed @javax.inject.Inject constructor(val navigator: ArtistAlbumNavigator) : androidx.lifecycle.ViewModel()
