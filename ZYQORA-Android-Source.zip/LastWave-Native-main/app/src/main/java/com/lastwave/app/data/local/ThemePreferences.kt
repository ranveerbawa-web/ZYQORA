package com.lastwave.app.data.local

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

enum class AccentMode(val storageValue: String) {
    MANUAL("manual"),
    DYNAMIC("dynamic"),
    MONOCHROME("monochrome");

    companion object {
        fun fromStorage(value: String?): AccentMode =
            entries.firstOrNull { it.storageValue == value } ?: MANUAL
    }
}

enum class ThemeMode(val storageValue: String) {
    SYSTEM("system"),
    LIGHT("light"),
    DARK("dark");

    companion object {
        fun fromStorage(value: String?): ThemeMode =
            entries.firstOrNull { it.storageValue == value } ?: SYSTEM
    }
}

data class ThemePrefs(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val accentColor: String = "#E03030",
    val accentLight: String = "#FF6060",
    val accentMode: AccentMode = AccentMode.MANUAL,
    val amoled: Boolean = false,
    /** iOS-style liquid-glass materials. Enabled by default. */
    val liquidGlass: Boolean = true,
    /** Optional Material 3 full-width navigation bar instead of the default floating dock. */
    val md3NavBar: Boolean = false,
    /** Whether bottom navigation tabs are completely hidden. */
    val hideNavTabs: Boolean = false,
    /** Dedicated ZYQORA Signature Theme inspired by the app logo icon (#C9FB00 & #012226). */
    val lastWaveTheme: Boolean = false,
)

@Singleton
class ThemePreferences @Inject constructor(
    private val dataStore: DataStore<Preferences>,
) {
    private object Keys {
        val THEME_MODE = stringPreferencesKey("lw_themeMode")
        val ACCENT_COLOR = stringPreferencesKey("lw_accent")
        val ACCENT_LIGHT = stringPreferencesKey("lw_accentLight")
        val ACCENT_MODE = stringPreferencesKey("lw_accentMode")
        val AMOLED = booleanPreferencesKey("lw_amoled")
        val LIQUID_GLASS = booleanPreferencesKey("lw_liquidGlass")
        val MD3_NAV_BAR = booleanPreferencesKey("lw_md3NavBar")
        val HIDE_NAV_TABS = booleanPreferencesKey("lw_hideNavTabs")
        val ZYQORA_THEME = booleanPreferencesKey("lw_ZYQORA_theme")
    }

    val prefs: Flow<ThemePrefs> = dataStore.data
        .recoverPreferences("ThemePreferences")
        .map { p ->
            ThemePrefs(
                themeMode = ThemeMode.fromStorage(p.readSafely(Keys.THEME_MODE)),
                accentColor = p.readSafely(Keys.ACCENT_COLOR) ?: "#E03030",
                accentLight = p.readSafely(Keys.ACCENT_LIGHT) ?: "#FF6060",
                accentMode = AccentMode.fromStorage(p.readSafely(Keys.ACCENT_MODE)),
                amoled = p.readSafely(Keys.AMOLED) ?: false,
                liquidGlass = p.readSafely(Keys.LIQUID_GLASS) ?: true,
                md3NavBar = p.readSafely(Keys.MD3_NAV_BAR) ?: false,
                hideNavTabs = p.readSafely(Keys.HIDE_NAV_TABS) ?: false,
                lastWaveTheme = p.readSafely(Keys.ZYQORA_THEME) ?: false,
            )
        }

    suspend fun setThemeMode(mode: ThemeMode) {
        dataStore.edit { it[Keys.THEME_MODE] = mode.storageValue }
    }

    suspend fun setManualAccent(color: String, light: String) {
        dataStore.edit {
            it[Keys.ACCENT_COLOR] = color
            it[Keys.ACCENT_LIGHT] = light
            it[Keys.ACCENT_MODE] = AccentMode.MANUAL.storageValue
            it[Keys.ZYQORA_THEME] = false
        }
    }

    suspend fun setMode(mode: AccentMode) {
        dataStore.edit {
            it[Keys.ACCENT_MODE] = mode.storageValue
            if (mode == AccentMode.DYNAMIC || mode == AccentMode.MONOCHROME) {
                it[Keys.ZYQORA_THEME] = false
            }
        }
    }

    suspend fun setAmoled(enabled: Boolean) {
        dataStore.edit { it[Keys.AMOLED] = enabled }
    }

    suspend fun setLiquidGlass(enabled: Boolean) {
        dataStore.edit { it[Keys.LIQUID_GLASS] = enabled }
    }

    suspend fun setMd3NavBar(enabled: Boolean) {
        dataStore.edit { it[Keys.MD3_NAV_BAR] = enabled }
    }

    suspend fun setHideNavTabs(enabled: Boolean) {
        dataStore.edit { it[Keys.HIDE_NAV_TABS] = enabled }
    }

    suspend fun setZYQORATheme(enabled: Boolean) {
        dataStore.edit {
            it[Keys.ZYQORA_THEME] = enabled
            if (enabled) {
                it[Keys.ACCENT_COLOR] = "#C9FB00"
                it[Keys.ACCENT_LIGHT] = "#C9FB00"
                it[Keys.ACCENT_MODE] = AccentMode.MANUAL.storageValue
            }
        }
    }
}
